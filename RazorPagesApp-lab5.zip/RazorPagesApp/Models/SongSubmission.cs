﻿namespace RazorPagesApp.Models
{
    public class SongSubmission
    {
        public int Submission_ID { get; set; }
        public string Submission_Title { get; set; }
        public string Submission_Type {  get; set; }
        public string Submission_Content { get; set; }
        public string Submission_Email { get; set; }

    }
}
